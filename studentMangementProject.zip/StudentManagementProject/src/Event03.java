import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.util.ArrayList;

import javax.swing.ComboBoxModel;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.*;
public class Event03 extends JFrame implements ActionListener{
	//private JComboBox jc;
	private ArrayList<Student> list123 = new ArrayList<Student>();

	public Event03(ArrayList<Student> list) {
		JFrame mainFrame = new JFrame();
		mainFrame.setTitle("학생 관리 프로그램");
		mainFrame.setVisible(true);
		mainFrame.setSize(400, 500);
		mainFrame.setLocation(100, 50);
		mainFrame.setDefaultCloseOperation(mainFrame.EXIT_ON_CLOSE);
		mainFrame.setLayout(null);
		
		//텍스트 표시
		JLabel jl1 = new JLabel("<학생 관리 프로그램>");
		jl1.setBounds(60, 30, 274, 10);
		jl1.setHorizontalAlignment(jl1.CENTER);
		mainFrame.add(jl1);
		
		JLabel jl2 = new JLabel("실행시킬 메뉴를 클릭하세요");
		jl2.setBounds(60, 50, 274, 13);
		jl2.setHorizontalAlignment(jl2.CENTER);
		mainFrame.add(jl2);
		
		String[] str = {"학생등록", "학생명단", "학생정보보기", "학생정보수정", "학생정보삭제", "프로그램종료"};
		
		for(int i = 0; i < str.length; i++) {
			JButton jb = new JButton(str[i]);
			jb.setSize(274, 40);
			jb.setLocation(60, 80 + 50*i);
			jb.addActionListener(this);
			jb.setLayout(null);
			mainFrame.add(jb);
		}
		
		
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		String value = e.getActionCommand().toString();
		JFrame posFrame = new JFrame();
		posFrame.setSize(350, 450);
		posFrame.setTitle(e.getActionCommand());
		posFrame.setLocation(120, 70);
		posFrame.setVisible(true);
		//posFrame.setDefaultCloseOperation(posFrame.EXIT_ON_CLOSE);
		posFrame.setLayout(null);
		
		switch(value) {
		case "학생등록":
			posFrame.setSize(350, 350);
			String[] stREs = {"이름: ", "학번: ", "학과: ", "번호: "};
			JLabel resLabel = new JLabel(e.getActionCommand());
			//위치 크기 설정
			resLabel.setSize(270, 40);
			resLabel.setLocation(40, 20);
			resLabel.setHorizontalAlignment(resLabel.CENTER);
			posFrame.add(resLabel);
			JButton resY = new JButton("확인");
			JButton resN = new JButton("취소");
			resY.setSize(70, 20);
			resN.setSize(70, 20);
			resY.setLocation(160, 260);
			resN.setLocation(240, 260);
			resY.setLayout(null);
			resN.setLayout(null);
			posFrame.add(resY);
			posFrame.add(resN);
			
			String[] saveValue = new String[4];
			JTextField jt1 = null; 
			JTextField[] jtArray = new JTextField[4];
			try {
			for(int i = 0; i < 4; i++) {
				jt1 = new JTextField();
				JLabel lb = new JLabel(stREs[i]);
				lb.setSize(50, 10);
				lb.setLocation(50, 70 + 30*i);
				lb.setHorizontalAlignment(lb.CENTER);
				jt1.setSize(160, 30);
				jt1.setLocation(110, 62 + 30*i);
				jt1.setHorizontalAlignment(jt1.CENTER);
				posFrame.add(jt1);
				posFrame.add(lb);
				jtArray[i] = jt1;
			}
			}catch(ArrayIndexOutOfBoundsException aiobe) {
				System.out.println("범위초과");
			}catch(NullPointerException npe) {
				System.out.println();
			}
			try {
				resY.addActionListener(event -> { 
					for(int j = 0; j < saveValue.length; j++) {
						saveValue[j] = jtArray[j].getText();
						System.out.println(saveValue.toString());
					}
					Student guy = new Student(saveValue[0], saveValue[1], saveValue[2], saveValue[3]);
					list123.add(guy);;
					posFrame.dispose();
				});
				resN.addActionListener(event -> {
					posFrame.dispose();
				});
			}catch(NullPointerException npe) {
			
			}
			break;
			
		case "학생명단":
			JScrollPane scp = new JScrollPane(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
			scp.setBounds(468, 5, 15, 650);
			posFrame.add(scp);
			posFrame.setSize(500, 700);
			JLabel listLabel = new JLabel(e.getActionCommand());
			//위치 크기 설정
			listLabel.setSize(280, 40);
			listLabel.setLocation(110, 10);
			listLabel.setHorizontalAlignment(listLabel.CENTER);
			posFrame.add(listLabel);
			String[] stuArr = new String[list123.size()];
				
			try{
				for(int i = 0; i < list123.size(); i++) {
					stuArr[i] = "(" + (i+1) + ") " + list123.get(i).toString();
					JLabel arrLabel = new JLabel(stuArr[i]);
					arrLabel.setSize(450, 40);
					arrLabel.setLocation(17, 55 + 30*i);
					arrLabel.setHorizontalAlignment(arrLabel.CENTER);
					posFrame.add(arrLabel);
				}
			}catch(NullPointerException npe) {
				System.out.println();
			}
			break;
		case "학생정보보기":
			posFrame.setSize(365, 170);
			JLabel infoLabel = new JLabel("정보가 필요한 학생의 이름을 입력하세요.");
			infoLabel.setSize(270, 40);
			infoLabel.setLocation(40, 20);
			infoLabel.setHorizontalAlignment(infoLabel.CENTER);
			JTextField searchName = new JTextField();
			searchName.setBounds(120, 60, 110, 22);
			searchName.setLayout(null);
			searchName.setHorizontalAlignment(searchName.CENTER);
			JButton okB = new JButton("확인");
			okB.setBounds(135, 95, 80, 18);
			posFrame.add(okB);
			posFrame.add(searchName);
			posFrame.add(infoLabel);
			try{
				okB.addActionListener(event -> {
			
				String sN = searchName.getText();
				posFrame.dispose();
				System.out.println(sN);
				JFrame stuInfo = new JFrame("학생 정보 조회");
				stuInfo.setBounds(120, 60, 350, 350);
				stuInfo.setLayout(null);
				
				JLabel infoLabel1 = new JLabel(sN + " 학생 조회 결과");
				infoLabel1.setBounds(40, 10, 270, 40);
				infoLabel1.setHorizontalAlignment(infoLabel1.CENTER);
				stuInfo.add(infoLabel1);
				stuInfo.setVisible(true);
				String[] stREs1 = {"이름: ", "학번: ", "학과: ", "번호: "};
				Student findStu = null;
				for(int i = 0; i < list123.size(); i++) {
					if(list123.get(i).toString().contains(sN)){
						findStu = list123.get(i);
						System.out.println(findStu.toString());
					}
				}
				String[] hihi = {findStu.getName(), findStu.getID(), findStu.getDEP(), findStu.getNum()};
				//입력받은 학생의 이름 학번 학과 번호 저장할 배열
				for(int i = 0; i < 4; i++) {
					JLabel info = new JLabel(hihi[i]);
					JLabel lb = new JLabel(stREs1[i]);
					lb.setSize(50, 10);
					lb.setLocation(50, 70 + 30*i);
					lb.setHorizontalAlignment(lb.CENTER);
					info.setSize(160, 30);
					info.setLocation(110, 62 + 30*i);
					info.setHorizontalAlignment(info.CENTER);
					stuInfo.add(lb);
					stuInfo.add(info);
				}
			});
			}catch(IndexOutOfBoundsException iobe) {
				System.out.println();
			}
			break;
		case "학생정보수정":
			posFrame.setSize(365, 170);
			JLabel editLabel = new JLabel("수정할 학생의 이름을 입력하세요.");
			editLabel.setSize(270, 40);
			editLabel.setLocation(40, 20);
			editLabel.setHorizontalAlignment(editLabel.CENTER);
			JTextField editName = new JTextField();
			editName.setBounds(120, 60, 110, 22);
			editName.setLayout(null);
			editName.setHorizontalAlignment(editName.CENTER);
			JButton okB1 = new JButton("확인");
			okB1.setBounds(135, 95, 80, 18);
			posFrame.add(okB1);
			posFrame.add(editLabel);
			posFrame.add(editName);
			okB1.addActionListener(event -> {
				String editStu = editName.getText();
				posFrame.dispose();
				JFrame editTap = new JFrame();
				editTap.setTitle("학생 정보 수정");
				editTap.setBounds(120, 60, 350, 350);
				editTap.setVisible(true); 
				
				
				JLabel firstStuValue = new JLabel(editStu + " 학생 정보 수정");
				firstStuValue.setBounds(38, 20, 270, 40);
				firstStuValue.setHorizontalAlignment(firstStuValue.CENTER);
				firstStuValue.setLayout(null);
				editTap.add(firstStuValue);	
				JButton editY = new JButton("수정");
				JButton editN = new JButton("취소");
				editY.setSize(70, 20);
				editN.setSize(70, 20);
				editY.setLocation(160, 260);
				editN.setLocation(240, 260);
				editY.setLayout(null);
				editN.setLayout(null);
				editTap.add(editY);
				editTap.add(editN);	
			
				//String[] saveValue2 = new String[4];
				
				String[] stREs2 = {"이름: ", "학번: ", "학과: ", "번호: "};
				JTextField[] jt2 = new JTextField[4];
								
									for(int i = 0; i < 4; i++) {
									jt2[i] = new JTextField();
									jt2[i].setLayout(null);
									JLabel lb = new JLabel(stREs2[i]);
									lb.setLayout(null);
									lb.setSize(50, 10);
									lb.setLocation(50, 70 + 30*i);
									lb.setHorizontalAlignment(lb.CENTER);
									jt2[i].setSize(160, 30);
									jt2[i].setLocation(110, 62 + 30*i);
									jt2[i].setHorizontalAlignment(jt2[i].CENTER);
									editTap.add(jt2[i]);
									editTap.add(lb);
									}
									//System.out.println(jtArray2[i]);
								
								
								//System.out.println(jtArray2);
								JLabel jl3 = new JLabel("번호: ");
								jl3.setBounds(50, 160, 50, 10);
								jl3.setHorizontalAlignment(jl3.CENTER);
								jl3.setLayout(null);
								editTap.add(jl3);
								
								try {
								editY.addActionListener(event2 -> {
									String[] jtArray2 = new String[4];
									for(int i = 0; i < 4; i++) {
										jtArray2[i] = jt2[i].getText();
									}
								for(int j = 0; j < list123.size(); j++) {
								System.out.println(list123.size());
								System.out.println("과연?");
								System.out.println(editStu.toString());
								System.out.println(list123.get(j).getName().toString());
								if(editStu.equals(list123.get(j).getName())) {
									
									System.out.println(jtArray2[2]);
									System.out.println("뭔데");
									Student finallyl = new Student(jtArray2[0], jtArray2[1], jtArray2[2], jtArray2[3]);
									//int finIndext = j;
									list123.set(j, finallyl);
								}
								}
								
								editTap.dispose();
								});
								}catch(NullPointerException npe) {
									
								}
							
							
						
					try {
					editN.addActionListener(event2 -> {
						editTap.dispose();
					});
				}catch(NullPointerException npe) {
				
				}
			});
			break;
		case "학생정보삭제":
			
			JScrollPane scp1 = new JScrollPane(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
			scp1.setBounds(468, 5, 15, 650);
			posFrame.add(scp1);
			posFrame.setSize(500, 700);
			JLabel listLabel1 = new JLabel(e.getActionCommand());
			//위치 크기 설정
			listLabel1.setSize(280, 40);
			listLabel1.setLocation(110, 10);
			listLabel1.setHorizontalAlignment(listLabel1.CENTER);
			posFrame.add(listLabel1);
			String[] stuArr1 = new String[list123.size()];
			JCheckBox[] jcb = new JCheckBox[list123.size()];
			try{
				for(int i = 0; i < list123.size(); i++) {
					jcb[i] = new JCheckBox(list123.get(i).toString());
					jcb[i].setBounds(12, 50 + 30*i, 550, 40);
					posFrame.add(jcb[i]);
				}
			}catch(NullPointerException npe) {
				System.out.println();
			}
			JButton acpt = new JButton("삭제");
			acpt.setBounds(210, 630, 60, 18);
			acpt.setHorizontalAlignment(acpt.CENTER);
			posFrame.add(acpt);
				acpt.addActionListener(event -> {
					for(int i = 0; i < list123.size(); i++) {
						if(jcb[i].isSelected()) {
							list123.remove(i);
						}
					}
					posFrame.dispose();
				});
			break;
		case "프로그램종료":
			System.exit(0);
			break;
		}
	}
	
}