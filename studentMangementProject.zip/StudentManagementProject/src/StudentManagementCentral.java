//import javax.swing.*;
//import java.awt.*;
//import java.awt.event.ActionEvent;
//import java.awt.event.ActionListener;
import java.util.*;

//import javax.swing.JButton;
//import javax.swing.JFrame;
//import javax.swing.JLabel;

public class StudentManagementCentral{
	void Student(String name, String ID, String DEP, String num) {
		
	}
	String name;//학생 이름
	String ID;//학생 학번
	String DEP;//학생 학과
	String num;//학생 번호
	static String findValue;//찾을 학생 이름
	static int total = 0;//총학생수
	static ArrayList<Student> list = new ArrayList<Student>();
	static Scanner s = new Scanner(System.in);
	
	public static void main(String[] args) {
		Event03 e = new Event03(list);
		
		int choice = 0;
		while(choice != 6) {
			System.out.println("<학생관리시스템>");
			System.out.println("1. 학생등록");
			System.out.println("2. 학생명단");
			System.out.println("3. 학생정보출력");
			System.out.println("4. 학생정보수정");
			System.out.println("5. 학생정보제거");
			System.out.println("6. 프로그램 종료");
			System.out.print("실행시킬 번호: ");
			
			try{
				choice = s.nextInt();
			}catch(InputMismatchException ime) {
				System.out.println("숫자만 입력할 수 있습니다.");
				System.out.println("프로그램을 다시 실행하세요.");
				break;
			}
			System.out.println();
			
			switch(choice) {
			case 1: 
			StuResister(); 
			list.add(inputStudent()); 
			total++;
			break;
			case 2:
				System.out.println("<학생 명단>");
				try{
					for(int i = 0; i < list.size(); i++){
						System.out.println((i+1) + "." + list.get(i).toString());
					}
					System.out.println("총학생수: " + total);
					System.out.println();
				}catch(IndexOutOfBoundsException iobe) {
					System.out.println();
				}
				break;
			case 3:
				//printSelStu(); 
				//break;
				System.out.println("<학생정보출력>");
				System.out.print("학생의 이름을 입력하세요: ");
				findValue = s.next();
				for(int i = 0; i < list.size(); i++) {
					if(list.get(i).toString().contains(findValue)){
						System.out.println(findValue + " 학생의 정보입니다.");
						System.out.println(list.get(i).toString());
						}
				}
				System.out.println();
				break;
			case 4:
				System.out.println("<학생 정보 수정>");
				System.out.println("<학생 명단>");
				try{
					for(int i = 0; i < list.size(); i++){
						System.out.println((i+1) + "." + list.get(i).toString());
					}
					System.out.println();
				}catch(IndexOutOfBoundsException iobe) {
					System.out.println();
				}
				System.out.print("정보를 수정할 학생의 번호를 입력하세요: ");
				int editNameValue = s.nextInt() - 1;
				System.out.println("무엇을 수정하시겠습니까?");
				System.out.println("1. 이름");
				System.out.println("2. 학번");
				System.out.println("3. 학과");
				System.out.println("4. 번호");
				System.out.println("5. 실행취소");
				int editValue = s.nextInt();
				System.out.println();
				
				switch(editValue) {
				case 1:
					System.out.print("변경 할 이름: ");
					String editName = s.next();
					list.get(editNameValue).setName(editName);
					System.out.println("변경이 완료되었습니다.");
					break;
				case 2:
					System.out.print("변경 할 학번: ");
					String editID = s.next();
					list.get(editNameValue).setID(editID);
					System.out.println("변경이 완료되었습니다.");
					break;
				case 3:
					System.out.print("변경 할 학과: ");
					String editDEP = s.next();
					list.get(editNameValue).setDEP(editDEP);
					System.out.println("변경이 완료되었습니다.");
					break;
				case 4:
					System.out.print("변경 할 번호: ");
					String editNum = s.next();
					list.get(editNameValue).setNum(editNum);
					System.out.println("변경이 완료되었습니다.");
					break;
				case 5:
					System.out.println("실행이 취소되었습니다.");
					break;
				}
				System.out.println();
				break;
			case 5: 
				int delChoice = 0;
				System.out.println("<학생 정보 삭제>");
				
				System.out.println("1. 선택삭제");
				System.out.println("2. 전체삭제(시스템초기화)");
				System.out.print("번호를 입력하세요: ");
				try{
					delChoice = s.nextInt();
				}catch(InputMismatchException ime) {
					System.out.println("올바른 값을 입력하세요.");
					System.out.println();
				}
				switch(delChoice) {
				case 1:
					System.out.println("학생 명단입니다.");
					try{
						for(int i = 0; i < list.size(); i++){
							System.out.println((i+1) + "." + list.get(i).toString());
						}
						System.out.println();
					}catch(IndexOutOfBoundsException iobe) {
						System.out.println();
					}
					System.out.println("삭제할 학생의 번호를 입력하세요.");
					int delStuNum = 0;
					try{
						delStuNum = s.nextInt() - 1;
					}
					catch(InputMismatchException ime) {
						System.out.println("올바른 값을 입력하세요.");
						System.out.println();
					}
						try{
							System.out.println(list.get(delStuNum).getName() + " 학생의 정보가 삭제되었습니다.");
							list.remove(delStuNum);
							total--;
						}catch(IndexOutOfBoundsException iobe) {
							System.out.println("올바른 값을 입력하세요.");
						}
					break;
				case 2:
						list.removeAll(list);
						System.out.println("정보가 초기화되었습니다.");
						total = 0;
					break;
				}
				System.out.println();
				break;
			case 6: 	
				System.out.println("프로그램이 종료되었습니다.");
				break;	
			}
		}
	}
		private static Student inputStudent() throws InputMismatchException {
		
		Scanner s = new Scanner(System.in);
		System.out.print("이름 : ");
		String name = s.next();
	
		System.out.print("학번 : ");
		String ID = s.next();
		
		System.out.print("학과 : ");
		String DEP = s.next();
		
		System.out.print("번호 : ");
		String num = s.next();
		
		System.out.println();
		
		return new Student(name, ID, DEP, num);
		}
		private static void StuResister() {
			System.out.println("[학생 정보 추가]");		
		}
}
