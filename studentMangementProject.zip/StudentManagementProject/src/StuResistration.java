import java.util.*;
public class StuResistration {
	Scanner s = new Scanner(System.in);
	private String name;
	private int ID;
	private String DEP;
	private String num;
	private int decide;
	
	public String StuResistration() {
		System.out.println("<학생등록프로그램>");
		System.out.print("이름: ");
		name = s.next();
		System.out.print("학번: ");
		ID = s.nextInt();
		System.out.print("학과: ");
		DEP = s.next();
		System.out.print("번호: ");
		num = s.next();
		System.out.println("신규등록학생정보: ");
		System.out.println(name + "/" + ID + "/" + DEP + "/" + num);
		System.out.println("등록을 원하시면 1, 아니면 2를 눌러주세요.");
		decide = s.nextInt();
		if(decide == 1) {
			System.out.println("학생이 등록되었습니다.");
			return num;
		}
		else {
			return "실행이 취소되었습니다.";
		}
	}
}
