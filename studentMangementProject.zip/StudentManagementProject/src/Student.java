public class Student {
    private String name;
    private String ID;
    private String DEP;
    private String num;

    public Student(String name, String ID, String DEP, String num){
        this.name = name;
        this.ID = ID;
        this.DEP = DEP;
        this.num = num;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getID() {
        return ID;
    }
    
    public void setID(String ID) {
    	this.ID = ID;
    }

    public String getDEP() {
        return DEP;
    }

    public void setDEP(String DEP) {
        this.DEP = DEP;
    }

    public String getNum() {
        return num;
    }

    public void setNum(String num) {
        this.num = num;
    }
    public String toString() {
    	return "[이름: " + name + ", 학번: " + ID + ", 학과: " + DEP + ", 번호: " + num + "]";
    }
}